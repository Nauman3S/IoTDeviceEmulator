rm -rf iot-dem.tar
tar -cvf iot-dem.tar *