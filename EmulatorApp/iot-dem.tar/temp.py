from config import *


print(PUB_PAYLOAD)
print(len(PUB_PAYLOAD))
print(PUB_PAYLOAD_CONFIG['PUBLISHING_INTERVAL'])